# roodle
Filtro tipo texto para la interpretación de código R dentro de las actividades y recursos de Moodle
